export interface FlickrPhoto {
  id: string;
  secret: string;
  server: string;
  title: string;
}
